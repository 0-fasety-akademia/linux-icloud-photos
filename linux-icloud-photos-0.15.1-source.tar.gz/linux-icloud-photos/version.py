VERSION = "0.15.1"
DATE = "2026-11-08"
CREDITS = "Created by: JGu\nSupported by Claude"
