#!/bin/bash
# Builds and installs the Flatpak locally. NOT tested by the author (no Flathub access when written).
# Usage: bash flatpak/build-flatpak.sh            (auto-detects the newest GNOME runtime)
#        RUNTIME_VERSION=50 FFMPEG_VERSION=25.08 bash flatpak/build-flatpak.sh
set -euo pipefail
cd "$(dirname "$0")"
APPID=local.icloudphotos.linux

sudo apt-get install -y flatpak flatpak-builder python3-pip python3-aiohttp python3-yaml curl
flatpak remote-add --if-not-exists --user flathub https://dl.flathub.org/repo/flathub.flatpakrepo

RV="${RUNTIME_VERSION:-$(flatpak remote-ls --user flathub --runtime --columns=application,branch \
      | awk '$1=="org.gnome.Platform" && $2 ~ /^[0-9]+$/ {print $2}' | sort -n | tail -1)}"
[ -n "$RV" ] || { echo "Could not detect the GNOME runtime. Set RUNTIME_VERSION=<number>."; exit 1; }
flatpak install --user -y flathub "org.gnome.Platform//$RV" "org.gnome.Sdk//$RV"

# freedesktop runtime version underlying GNOME (needed for the ffmpeg-full codec extension)
FV="${FFMPEG_VERSION:-$(flatpak info --user --show-metadata "org.gnome.Platform//$RV" 2>/dev/null \
      | sed -n 's#^runtime=org.freedesktop.Platform/[^/]*/##p' | head -1)}"
[ -n "$FV" ] || { echo "Could not detect the freedesktop version. Set FFMPEG_VERSION=<e.g. 25.08>."; exit 1; }
flatpak install --user -y flathub "org.freedesktop.Platform.ffmpeg-full//$FV" || true

# Python dependencies as offline modules (pyicloud, keyring, pychromecast, pyatv)
if [ ! -f flatpak-pip-generator ]; then
  curl -fsSL https://raw.githubusercontent.com/flatpak/flatpak-builder-tools/master/pip/flatpak-pip-generator \
       -o flatpak-pip-generator
fi
python3 flatpak-pip-generator --runtime "org.gnome.Sdk//$RV" --output python3-deps \
        pyicloud keyring pychromecast pyatv

sed -e "s/@RUNTIME_VERSION@/$RV/" -e "s/@FFMPEG_VERSION@/$FV/" \
    local.icloudphotos.linux.yml > "$APPID.build.yml"

flatpak-builder --user --install --force-clean --install-deps-from=flathub \
                build-dir "$APPID.build.yml"
flatpak build-bundle ~/.local/share/flatpak/repo "../$APPID.flatpak" "$APPID"
echo "Installed. Run:  flatpak run $APPID"
echo "Bundle for sharing: $(realpath ../$APPID.flatpak)"
