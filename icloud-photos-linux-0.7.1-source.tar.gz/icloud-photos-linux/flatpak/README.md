# Flatpak package (experimental)

The Flatpak bundles GTK 4, libadwaita and GStreamer from the GNOME runtime, so it behaves the same
on any distribution and does not depend on Ubuntu package names.

**Status: written but not built or tested by the author** (the sandbox it was written in could not
reach Flathub). Expect to fix small things on the first build.

Build and install locally:

    bash flatpak/build-flatpak.sh
    flatpak run local.icloudphotos.linux

Notes:
- `mpv` is not available inside the sandbox, so videos play in the built-in GTK player (GStreamer + the
  `ffmpeg-full` codec extension). HEIC originals may not decode (no HEIF loader in the runtime); the
  JPEG preview is used instead.
- Permissions: network (iCloud, TV discovery), Wayland/X11, GPU, audio, and the secret service (keyring).
- To publish on Flathub the app id must be changed to a domain you own (for example
  `io.github.<user>.ICloudPhotos`), screenshots must be added to the metainfo file, and Flathub requires
  all Python dependencies to be listed with checksums (generated into `python3-deps.json`).
