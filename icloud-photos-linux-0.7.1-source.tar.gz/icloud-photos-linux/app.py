#!/usr/bin/env python3
"""iCloud Photos dla Ubuntu - strumieniowo z chmury, bez synchronizacji na dysk."""
import json
import math
import os
import shutil
import subprocess
import sys
import threading
import time
import weakref
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor

# Wtyczki GStreamera zlinkowane z GTK3 (gtkwaylandsink) lub DirectFB wciągnięte do
# procesu GTK4 potrafią go wywrócić przy odtwarzaniu wideo - wyłączamy je z autowyboru.
os.environ["GST_PLUGIN_FEATURE_RANK"] = ",".join(
    x for x in (os.environ.get("GST_PLUGIN_FEATURE_RANK", ""),
                "gtkwaylandsink:0", "dfbvideosink:0") if x
)

import gi  # noqa: E402

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Adw, Gdk, GdkPixbuf, Gio, GLib, GObject, Gtk, Pango  # noqa: E402

import cast as dlna  # noqa: E402
import airplay  # noqa: E402
import cast_gc  # noqa: E402
from version import DATE, VERSION  # noqa: E402
from backend import CACHE_DIR, CONFIG_DIR, DEBUG_LOG, ICloud, log, prune_cache  # noqa: E402

try:
    import keyring
except ImportError:  # opcjonalne
    keyring = None

KEYRING_SERVICE = "icloud-photos-linux"
CONFIG_FILE = CONFIG_DIR / "config.json"
TILE_MIN, TILE_MAX, TILE_DEFAULT = 90, 360, 180
POOL = ThreadPoolExecutor(max_workers=6)
COVER_POOL = ThreadPoolExecutor(max_workers=3)
BATCH = 300
SLIDE_SECS = (3, 5, 8, 15)
PRESETS = (('Małe', 100), ('Standardowe', 180), ('Duże', 260), ('Bardzo duże', 360))

CSS = b"""
.tile { background-color: alpha(currentColor, 0.08); }
.viewer { background-color: black; }
.caption { color: white; background-color: rgba(0,0,0,0.55);
           padding: 4px 12px; border-radius: 8px; margin: 12px; }
.zbar { background-color: rgba(0,0,0,0.6); border-radius: 14px; padding: 4px 10px;
        margin: 16px; }
.zbar button { color: white; }
.albumcover { border-radius: 8px; background-color: alpha(currentColor, 0.1); }
.livebadge { color: white; background-color: rgba(0,0,0,0.55); font-size: 9px;
             font-weight: bold; padding: 1px 6px; border-radius: 6px; margin: 6px; }
"""


def load_cfg():
    try:
        return json.loads(CONFIG_FILE.read_text())
    except Exception:  # noqa: BLE001
        return {}


def save_cfg(**kv):
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        cfg = load_cfg()
        cfg.update(kv)
        CONFIG_FILE.write_text(json.dumps(cfg))
    except Exception:  # noqa: BLE001
        pass


def bg(fn, cb):
    """Uruchom fn w wątku, wynik (result, error) oddaj do cb w głównym wątku."""
    def run():
        try:
            res = (fn(), None)
        except Exception as e:  # noqa: BLE001
            res = (None, e)

        def deliver():
            cb(*res)
            return False

        GLib.idle_add(deliver)

    threading.Thread(target=run, daemon=True).start()


class PhotoObj(GObject.Object):
    def __init__(self, asset, is_video, is_live):
        super().__init__()
        self.asset = asset
        self.is_video = is_video
        self.is_live = is_live


class TexCache:
    """Mały cache tekstur w RAM (reszta leci z cache na dysku)."""

    def __init__(self, n=600):
        self.d = OrderedDict()
        self.n = n

    def get(self, k):
        t = self.d.get(k)
        if t is not None:
            self.d.move_to_end(k)
        return t

    def put(self, k, t):
        self.d[k] = t
        self.d.move_to_end(k)
        while len(self.d) > self.n:
            self.d.popitem(last=False)


def make_texture(data: bytes) -> Gdk.Texture:
    return Gdk.Texture.new_from_bytes(GLib.Bytes.new(data))


def make_square_texture(data: bytes, size: int = 96) -> Gdk.Texture:
    """Kwadratowy wycinek ze środka obrazu (okładki albumów) o stałym rozmiarze."""
    try:
        loader = GdkPixbuf.PixbufLoader()
        loader.write(data)
        loader.close()
        pb = loader.get_pixbuf()
        w, h = pb.get_width(), pb.get_height()
        side = min(w, h)
        pb = pb.new_subpixbuf((w - side) // 2, (h - side) // 2, side, side)
        pb = pb.scale_simple(size, size, GdkPixbuf.InterpType.BILINEAR)
        return Gdk.Texture.new_for_pixbuf(pb)
    except Exception:  # noqa: BLE001
        return make_texture(data)


class Tile(Gtk.Overlay):
    def __init__(self, size=TILE_DEFAULT):
        super().__init__()
        self.bound = None
        self.future = None
        self.on_context = None
        rc = Gtk.GestureClick()
        rc.set_button(3)
        rc.connect("pressed", lambda g, n, x, y: self.on_context and self.on_context(self, x, y))
        self.add_controller(rc)
        self.pic = Gtk.Picture()
        self.pic.set_size_request(size, size)
        self.pic.set_content_fit(Gtk.ContentFit.COVER)
        self.pic.add_css_class("tile")
        self.set_child(self.pic)
        self.vbadge = Gtk.Image.new_from_icon_name("media-playback-start-symbolic")
        self.vbadge.add_css_class("osd")
        self.vbadge.set_halign(Gtk.Align.END)
        self.vbadge.set_valign(Gtk.Align.END)
        self.vbadge.set_margin_end(6)
        self.vbadge.set_margin_bottom(6)
        self.add_overlay(self.vbadge)
        self.ph = Gtk.Image()
        self.ph.set_pixel_size(max(24, size // 3))
        self.ph.set_halign(Gtk.Align.CENTER)
        self.ph.set_valign(Gtk.Align.CENTER)
        self.ph.add_css_class("dim-label")
        self.ph.set_visible(False)
        self.ph.set_can_target(False)
        self.add_overlay(self.ph)
        self.lbadge = Gtk.Label(label="LIVE")
        self.lbadge.add_css_class("livebadge")
        self.lbadge.set_halign(Gtk.Align.START)
        self.lbadge.set_valign(Gtk.Align.START)
        self.add_overlay(self.lbadge)

    def set_fit(self, original):
        """original=True: cała fotografia w oryginalnych proporcjach (bez przycinania)."""
        self.pic.set_content_fit(Gtk.ContentFit.CONTAIN if original else Gtk.ContentFit.COVER)

    def set_size(self, n):
        self.pic.set_size_request(n, n)
        self.ph.set_pixel_size(max(24, n // 3))


class ZoomView(Gtk.ScrolledWindow):
    """Obraz z zoomem: Ctrl+kółko, +/-/0, szczypanie, dwuklik; przeciąganie = pan."""

    MAX_Z = 8.0

    def __init__(self, on_zoom=None):
        super().__init__()
        self.on_zoom = on_zoom
        self.zoom = 1.0
        self.aspect = 0.0
        self._mx = self._my = 0.0
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.NEVER)
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.pic = Gtk.Picture()
        self.pic.set_can_shrink(True)
        self.pic.set_content_fit(Gtk.ContentFit.CONTAIN)
        self.set_child(self.pic)

        motion = Gtk.EventControllerMotion()
        motion.connect("motion", lambda c, x, y: self._track(x, y))
        self.add_controller(motion)

        scroll = Gtk.EventControllerScroll.new(Gtk.EventControllerScrollFlags.VERTICAL)
        scroll.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        scroll.connect("scroll", self._on_scroll)
        self.add_controller(scroll)

        click = Gtk.GestureClick()
        click.set_button(1)
        click.connect("pressed", self._on_click)
        self.add_controller(click)

        self.on_longpress = None
        self.on_context = None
        lp = Gtk.GestureLongPress()
        lp.connect("pressed", lambda g, x, y: self.zoom <= 1.0 and self.on_longpress
                   and self.on_longpress())
        self.add_controller(lp)
        rc = Gtk.GestureClick()
        rc.set_button(3)
        rc.connect("pressed", lambda g, n, x, y: self.on_context and self.on_context(x, y))
        self.add_controller(rc)

        drag = Gtk.GestureDrag()
        drag.connect("drag-begin", self._drag_begin)
        drag.connect("drag-update", self._drag_update)
        self.add_controller(drag)
        self._drag0 = (0.0, 0.0)

        pinch = Gtk.GestureZoom()
        pinch.connect("begin", lambda g, s: setattr(self, "_pz", self.zoom))
        pinch.connect("scale-changed", lambda g, sc: self.set_zoom(self._pz * sc,
                                                                   self._mx, self._my))
        self.add_controller(pinch)
        self._pz = 1.0

    def _track(self, x, y):
        self._mx, self._my = x, y

    # --- obraz ---
    def set_image(self, tex, keep_zoom=False):
        if tex is None:
            self.pic.set_paintable(None)
            self.aspect = 0.0
            self.set_zoom(1.0)
            return
        self.aspect = tex.get_width() / max(1, tex.get_height())
        self.pic.set_paintable(tex)
        if not keep_zoom:
            self.set_zoom(1.0)

    def _fit_size(self):
        vw, vh = self.get_width(), self.get_height()
        if self.aspect <= 0 or vw <= 0 or vh <= 0:
            return float(max(vw, 1)), float(max(vh, 1))
        if vw / vh > self.aspect:
            return vh * self.aspect, float(vh)
        return float(vw), vw / self.aspect

    # --- zoom ---
    def set_zoom(self, z, px=None, py=None):
        z = max(1.0, min(self.MAX_Z, z))
        h, v = self.get_hadjustment(), self.get_vadjustment()
        vw, vh = self.get_width(), self.get_height()
        if px is None:
            px, py = vw / 2, vh / 2
        cw0, ch0 = max(h.get_upper(), 1.0), max(v.get_upper(), 1.0)
        fx, fy = (h.get_value() + px) / cw0, (v.get_value() + py) / ch0

        self.zoom = z
        if z <= 1.0001:
            self.zoom = 1.0
            self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.NEVER)
            self.pic.set_size_request(-1, -1)
            h.set_value(0)
            v.set_value(0)
        else:
            fw, fh = self._fit_size()
            self.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            self.pic.set_size_request(int(fw * z), int(fh * z))
            tw, th = max(vw, fw * z), max(vh, fh * z)
            tries = [0]

            def settle(_w, _clock):
                tries[0] += 1
                if h.get_upper() >= tw - 2 and v.get_upper() >= th - 2:
                    h.set_value(fx * h.get_upper() - px)
                    v.set_value(fy * v.get_upper() - py)
                    return GLib.SOURCE_REMOVE
                return GLib.SOURCE_REMOVE if tries[0] > 30 else GLib.SOURCE_CONTINUE

            self.add_tick_callback(settle)
        if self.on_zoom:
            self.on_zoom(self.zoom)

    def zoom_by(self, factor):
        self.set_zoom(self.zoom * factor, self._mx or None, self._my or None)

    # --- sterowanie ---
    def _on_scroll(self, ctrl, _dx, dy):
        state = ctrl.get_current_event_state()
        if state & Gdk.ModifierType.CONTROL_MASK:
            self.zoom_by(1 / 1.15 if dy > 0 else 1.15)
            return True
        return self.zoom <= 1.0  # przy 1x połykamy; przy zoomie kółko = przewijanie

    def _on_click(self, _g, n, x, y):
        if n == 2:
            self.set_zoom(1.0 if self.zoom > 1.0 else 2.5, x, y)

    def _drag_begin(self, _g, _x, _y):
        self._drag0 = (self.get_hadjustment().get_value(),
                       self.get_vadjustment().get_value())

    def _drag_update(self, _g, dx, dy):
        if self.zoom > 1.0:
            self.get_hadjustment().set_value(self._drag0[0] - dx)
            self.get_vadjustment().set_value(self._drag0[1] - dy)


class Viewer(Gtk.Window):
    def __init__(self, win, index):
        super().__init__(transient_for=win, title="Podgląd")
        self.win = win
        self.store = win.store
        self.index = index
        self.token = 0
        self.live_mode = False
        self.orig_done = False
        self._media = None
        self._sigs = []
        self._zguard = False
        self._extra = ""
        self.set_default_size(1200, 800)
        self.add_css_class("viewer")

        self.zv = ZoomView(self._on_zoom)
        self.zv.on_longpress = lambda: self.play_live()  # przytrzymaj = Live Photo
        self.zv.on_context = lambda x, y: self.win.show_context_menu(
            self.zv, x, y, self.store.get_item(self.index))
        self.video = Gtk.Video()
        self.video.set_autoplay(True)
        self.stack = Gtk.Stack()
        self.stack.add_named(self.zv, "img")
        self.stack.add_named(self.video, "vid")

        self.caption = Gtk.Label()
        self.caption.add_css_class("caption")
        self.caption.set_halign(Gtk.Align.START)
        self.caption.set_valign(Gtk.Align.END)
        self.caption.set_can_target(False)
        self.spinner = Gtk.Spinner()
        self.spinner.set_halign(Gtk.Align.CENTER)
        self.spinner.set_valign(Gtk.Align.CENTER)
        self.spinner.set_size_request(48, 48)
        self.spinner.set_can_target(False)
        self.live_btn = Gtk.Button(label="◉ LIVE")
        self.live_btn.add_css_class("osd")
        self.live_btn.add_css_class("pill")
        self.live_btn.set_halign(Gtk.Align.END)
        self.live_btn.set_valign(Gtk.Align.START)
        self.live_btn.set_margin_top(12)
        self.live_btn.set_margin_end(64)
        self.live_btn.connect("clicked", lambda *_: self.play_live())

        self.play_btn = Gtk.Button(icon_name="media-playback-start-symbolic")
        self.play_btn.add_css_class("osd")
        self.play_btn.add_css_class("circular")
        self.play_btn.set_size_request(80, 80)
        self.play_btn.set_halign(Gtk.Align.CENTER)
        self.play_btn.set_valign(Gtk.Align.CENTER)
        self.play_btn.set_tooltip_text("Odtwórz (Spacja / Enter)")
        self.play_btn.set_visible(False)
        self.play_btn.connect("clicked", lambda *_: self._play_video())

        # pasek zoomu: − [suwak] + Dopasuj
        self.zbar = Gtk.Box(spacing=6)
        self.zbar.add_css_class("zbar")
        self.zbar.set_halign(Gtk.Align.CENTER)
        self.zbar.set_valign(Gtk.Align.END)
        b_out = Gtk.Button(icon_name="zoom-out-symbolic")
        b_out.add_css_class("flat")
        b_out.set_tooltip_text("Pomniejsz (Ctrl −)")
        b_out.connect("clicked", lambda *_: self.zv.zoom_by(1 / 1.25))
        self.zscale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0.0, 1.0, 0.01)
        self.zscale.set_draw_value(False)
        self.zscale.set_size_request(180, -1)
        self.zscale.connect("value-changed", self._on_zscale)
        b_in = Gtk.Button(icon_name="zoom-in-symbolic")
        b_in.add_css_class("flat")
        b_in.set_tooltip_text("Powiększ (Ctrl +)")
        b_in.connect("clicked", lambda *_: self.zv.zoom_by(1.25))
        b_fit = Gtk.Button(label="Dopasuj")
        b_fit.add_css_class("flat")
        b_fit.set_tooltip_text("Dopasuj do okna (Ctrl 0)")
        b_fit.connect("clicked", lambda *_: self.zv.set_zoom(1.0))
        for w in (b_out, self.zscale, b_in, b_fit):
            self.zbar.append(w)

        self.info_btn = Gtk.Button(icon_name="dialog-information-symbolic")
        self.info_btn.add_css_class("osd")
        self.info_btn.add_css_class("circular")
        self.info_btn.set_halign(Gtk.Align.END)
        self.info_btn.set_valign(Gtk.Align.START)
        self.info_btn.set_margin_top(12)
        self.info_btn.set_margin_end(12)
        self.info_btn.set_tooltip_text("Informacje o zdjęciu (I)")
        self.info_btn.connect(
            "clicked", lambda *_: self.win.show_info(self.store.get_item(self.index)))

        ov = Gtk.Overlay()
        ov.set_child(self.stack)
        for w in (self.caption, self.spinner, self.live_btn, self.info_btn, self.play_btn,
                  self.zbar):
            ov.add_overlay(w)
        self.set_child(ov)

        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self.on_key)
        self.add_controller(keys)
        self.connect("close-request", lambda *_: (self._stop_video(), False)[1])

        self.show_index(index)

    # --- klawisze ---
    def toggle_fs(self):
        if self.is_fullscreen():
            self.unfullscreen()
        else:
            self.fullscreen()

    def on_key(self, _c, keyval, _code, _state):
        on_video = self.stack.get_visible_child_name() == "vid"
        if keyval in (Gdk.KEY_Right, Gdk.KEY_Page_Down):
            self.show_index(self.index + 1)
        elif keyval in (Gdk.KEY_Left, Gdk.KEY_Page_Up):
            self.show_index(self.index - 1)
        elif keyval == Gdk.KEY_Home:
            self.show_index(0)
        elif keyval == Gdk.KEY_End:
            self.show_index(self.store.get_n_items() - 1)
        elif keyval in (Gdk.KEY_f, Gdk.KEY_F, Gdk.KEY_F11):
            self.toggle_fs()
        elif keyval == Gdk.KEY_Escape:
            if self.is_fullscreen():
                self.unfullscreen()
            else:
                self.close()
        elif keyval in (Gdk.KEY_plus, Gdk.KEY_equal, Gdk.KEY_KP_Add, Gdk.KEY_asterisk):
            self.zv.zoom_by(1.25)
        elif keyval in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract, Gdk.KEY_underscore):
            self.zv.zoom_by(1 / 1.25)
        elif keyval in (Gdk.KEY_0, Gdk.KEY_KP_0):
            self.zv.set_zoom(1.0)
        elif keyval in (Gdk.KEY_space, Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            cur = self.store.get_item(self.index)
            if on_video and self._media is not None:
                self._media.set_playing(not self._media.get_playing())
            elif cur.is_video:
                self._play_video()
            else:
                self.play_live()
        elif keyval in (Gdk.KEY_l, Gdk.KEY_L):
            self.play_live()
        elif keyval in (Gdk.KEY_i, Gdk.KEY_I):
            self.win.show_info(self.store.get_item(self.index))
        elif keyval in (Gdk.KEY_m, Gdk.KEY_M):
            obj = self.store.get_item(self.index)
            self.win.play_external(
                obj, self.win.icloud.live_version(obj.asset) if self.live_mode else None)
        else:
            return False
        return True

    # --- wyświetlanie ---
    def _label(self, extra=""):
        n = self.store.get_n_items()
        obj = self.store.get_item(self.index)
        s = f"{obj.asset.filename}   ({self.index + 1}/{n})"
        if self.zv.zoom > 1.0:
            s += f"   {self.zv.zoom:.1f}×"
        return s + (f"   {extra}" if extra else "")

    def _on_zscale(self, sc):
        if not self._zguard:
            self.zv.set_zoom(ZoomView.MAX_Z ** sc.get_value())

    def _page(self, name):
        self.stack.set_visible_child_name(name)
        self.zbar.set_visible(name == "img")
        if name == "vid":
            self.play_btn.set_visible(False)

    def _on_zoom(self, z):
        if hasattr(self, "zscale"):
            self._zguard = True
            self.zscale.set_value(math.log(max(z, 1.0)) / math.log(ZoomView.MAX_Z))
            self._zguard = False
        if hasattr(self, "store") and self.store.get_n_items():
            self.caption.set_text(self._label(getattr(self, "_extra", "")))
        if z > 1.5:
            self._upgrade_original()

    def show_index(self, i):
        n = self.store.get_n_items()
        if n == 0:
            return
        self._stop_video()
        self.index = max(0, min(n - 1, i))
        self.token += 1
        token = self.token
        self.orig_done = False
        self.live_mode = False
        self._extra = ""
        obj = self.store.get_item(self.index)
        self.win.last_obj = obj
        self.live_btn.set_visible(obj.is_live)

        if obj.is_video and not self.win.external_video_ok():
            self._page("vid")  # tryb wbudowany (bez mpv)
            self.caption.set_text(self._label("(Spacja = pauza, M = mpv)"))
            self._play(obj, self.win.icloud.video_version(obj.asset, True))
            return

        self._page("img")
        self.play_btn.set_visible(obj.is_video)  # film: plakat + przycisk ▶
        if not obj.is_video:
            self.win.cast_asset(obj.asset)
        self.zv.set_image(self.win.tex.get(obj.asset.id))
        hint = ("(Spacja/Enter/▶ = odtwórz)" if obj.is_video
                else "(L/Spacja = Live)" if obj.is_live else "")
        self.caption.set_text(self._label(hint))
        self.spinner.start()

        def work():
            return make_texture(self.win.icloud.fetch(obj.asset, "medium"))

        def done(tex, err):
            if token != self.token:
                return
            self.spinner.stop()
            if err:
                self.caption.set_text(self._label(f"[błąd: {err}]"))
            else:
                self.zv.set_image(tex)

        bg(work, done)
        for j in (self.index + 1, self.index - 1):  # prefetch sąsiadów do cache
            if 0 <= j < n:
                POOL.submit(self._safe_fetch, self.store.get_item(j).asset)

    def _safe_fetch(self, asset):
        try:
            self.win.icloud.fetch(asset, "medium")
        except Exception:  # noqa: BLE001
            pass

    def _upgrade_original(self):
        obj = self.store.get_item(self.index)
        if self.orig_done or obj.is_video:
            return
        self.orig_done = True
        token = self.token

        def work():
            return make_texture(self.win.icloud.fetch_original(obj.asset))

        def done(tex, err):
            if token != self.token:
                return
            if err:
                self._extra = "(oryginał niedostępny: brak dekodera HEIC?)"
            else:
                self._extra = "(oryginał)"
                self.zv.set_image(tex, keep_zoom=True)
            self.caption.set_text(self._label(self._extra))

        self.spinner.start()
        bg(work, lambda t, e: (self.spinner.stop(), done(t, e)))

    # --- wideo / Live Photos ---
    def _play_video(self):
        obj = self.store.get_item(self.index)
        if not obj.is_video:
            return
        if self.win.cast_target is not None:
            self.win.cast_asset(obj.asset)
            self.caption.set_text(self._label("(wysłano na TV)"))
        elif self.win.external_video_ok():
            self.win.play_external(obj)
        else:
            self._page("vid")
            self._play(obj, self.win.icloud.video_version(obj.asset, True))

    def _play(self, obj, ver):
        if ver is None:
            self.caption.set_text(self._label("[brak wersji wideo]"))
            return
        url = self.win.icloud.stream_url(obj.asset, ver)
        self.video.set_file(Gio.File.new_for_uri(url))
        m = self.video.get_media_stream()
        self._media = m
        if m is not None:
            self._sigs = [m.connect("notify::error", self._on_media_error),
                          m.connect("notify::ended", self._on_ended)]
            token = self.token

            def watchdog():  # wbudowany odtwarzacz nie wystartował -> mpv
                if (token == self.token and self._media is m
                        and not m.is_prepared() and m.get_error() is None):
                    self._fallback("[wbudowany odtwarzacz nie wystartował]")
                return False

            GLib.timeout_add_seconds(8, watchdog)

    def _fallback(self, why):
        """Zapas: otwórz bieżące wideo w osobnym oknie mpv (raz na pozycję)."""
        obj = self.store.get_item(self.index)
        if getattr(self, "_fb_done", None) == (self.token, self.live_mode):
            return
        self._fb_done = (self.token, self.live_mode)
        ver = self.win.icloud.live_version(obj.asset) if self.live_mode else None
        url = getattr(self, "_cur_path", None) if self.live_mode else None
        ok = self.win.play_external(obj, ver, url=url)
        self.caption.set_text(self._label(why + (" → mpv" if ok else " (zainstaluj mpv)")))

    def _stop_video(self):
        m, self._media = self._media, None
        if m is not None:
            for s in self._sigs:
                m.disconnect(s)
            m.set_playing(False)
        self._sigs = []
        self.video.set_file(None)

    def _on_media_error(self, m, _p):
        if m.get_error() is not None:
            log.error("błąd odtwarzacza GTK: %s", m.get_error())
            self._fallback("[GStreamer nie odtworzył - brak kodeka?]")

    def _on_ended(self, m, _p):
        if self.live_mode and m.get_ended():
            self.live_mode = False
            token = self.token

            def back():  # nie zatrzymujemy strumienia w jego własnym sygnale
                if token == self.token:
                    self._stop_video()
                    self._page("img")
                return False

            GLib.idle_add(back)

    def play_live(self):
        obj = self.store.get_item(self.index)
        if not obj.is_live or self.live_mode:
            return
        ver = self.win.icloud.live_version(obj.asset)
        if ver is None:
            self.caption.set_text(self._label("[brak części wideo tego Live Photo]"))
            return
        self.live_mode = True
        token = self.token
        self.spinner.start()
        self.caption.set_text(self._label("(pobieram Live Photo…)"))

        def work():
            return self.win.icloud.fetch_live(obj.asset, ver)

        def done(path, err):
            self.spinner.stop()
            if token != self.token or not self.live_mode:
                return
            if err:
                self.live_mode = False
                log.error("Live Photo %s: %r", obj.asset.filename, err)
                self.caption.set_text(self._label(f"[Live Photo: {err}]"))
                return
            log.info("Live Photo: %s (%s)", obj.asset.filename, path)
            self._page("vid")
            self._play_path(path)

        bg(work, done)

    def _play_path(self, path):
        """Odtwarza lokalny plik (krótki klip Live Photo); gdy się nie uda - mpv."""
        self._cur_path = path
        self.video.set_file(Gio.File.new_for_path(path))
        m = self.video.get_media_stream()
        self._media = m
        if m is not None:
            self._sigs = [m.connect("notify::error", self._on_media_error),
                          m.connect("notify::ended", self._on_ended)]
            token = self.token

            def watchdog():
                if (token == self.token and self._media is m
                        and not m.is_prepared() and m.get_error() is None):
                    self._fallback("[wbudowany odtwarzacz nie wystartował]")
                return False

            GLib.timeout_add_seconds(4, watchdog)


class Slideshow(Gtk.Window):
    """Pokaz slajdów bieżącego albumu: PLAY/pauza, ←/→, odstęp, wysyłka na TV."""

    def __init__(self, win, start=0):
        super().__init__(transient_for=win, title="Pokaz slajdów")
        self.win = win
        self.store = win.store
        self.i = start - 1
        self.playing = True
        self.token = 0
        self.secs = win.slide_secs
        self._timer = 0
        self._hide = 0
        self.front = 0
        self.set_default_size(1200, 800)
        self.add_css_class("viewer")

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.stack.set_transition_duration(700)
        self.pics = []
        for name in ("0", "1"):
            pic = Gtk.Picture()
            pic.set_can_shrink(True)
            pic.set_content_fit(Gtk.ContentFit.CONTAIN)
            self.stack.add_named(pic, name)
            self.pics.append(pic)

        self.caption = Gtk.Label()
        self.caption.add_css_class("caption")
        self.caption.set_halign(Gtk.Align.START)
        self.caption.set_valign(Gtk.Align.START)
        self.caption.set_can_target(False)

        bar = Gtk.Box(spacing=6)
        bar.add_css_class("zbar")
        prev = Gtk.Button(icon_name="media-skip-backward-symbolic")
        self.pp = Gtk.Button(icon_name="media-playback-pause-symbolic")
        nxt = Gtk.Button(icon_name="media-skip-forward-symbolic")
        for b in (prev, self.pp, nxt):
            b.add_css_class("flat")
        prev.connect("clicked", lambda *_: self.go(-1))
        nxt.connect("clicked", lambda *_: self.go(1))
        self.pp.connect("clicked", lambda *_: self.toggle())
        self.dd = Gtk.DropDown.new_from_strings([f"{n} s" for n in SLIDE_SECS])
        self.dd.set_selected(min(range(len(SLIDE_SECS)),
                                 key=lambda k: abs(SLIDE_SECS[k] - self.secs)))
        self.dd.connect("notify::selected", self._on_secs)
        close = Gtk.Button(icon_name="window-close-symbolic")
        close.add_css_class("flat")
        close.connect("clicked", lambda *_: self.close())
        for w in (prev, self.pp, nxt, self.dd, close):
            bar.append(w)
        self.rev = Gtk.Revealer()
        self.rev.set_transition_type(Gtk.RevealerTransitionType.CROSSFADE)
        self.rev.set_child(bar)
        self.rev.set_halign(Gtk.Align.CENTER)
        self.rev.set_valign(Gtk.Align.END)
        self.rev.set_reveal_child(True)

        ov = Gtk.Overlay()
        ov.set_child(self.stack)
        ov.add_overlay(self.caption)
        ov.add_overlay(self.rev)
        self.set_child(ov)

        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self._on_key)
        self.add_controller(keys)
        motion = Gtk.EventControllerMotion()
        motion.connect("motion", lambda *_: self._show_bar())
        self.add_controller(motion)
        self.connect("close-request", self._on_close)
        self.fullscreen()
        self._show_bar()
        self.go(1)

    # --- sterowanie ---
    def _on_key(self, _c, keyval, _code, _state):
        if keyval in (Gdk.KEY_Right, Gdk.KEY_Page_Down):
            self.go(1)
        elif keyval in (Gdk.KEY_Left, Gdk.KEY_Page_Up):
            self.go(-1)
        elif keyval == Gdk.KEY_space:
            self.toggle()
        elif keyval == Gdk.KEY_Escape:
            self.close()
        elif keyval in (Gdk.KEY_f, Gdk.KEY_F, Gdk.KEY_F11):
            self.unfullscreen() if self.is_fullscreen() else self.fullscreen()
        else:
            return False
        self._show_bar()
        return True

    def _on_secs(self, dd, _p):
        self.secs = SLIDE_SECS[dd.get_selected()]
        self.win.slide_secs = self.secs
        save_cfg(slide_secs=self.secs)
        if self.playing:
            self._schedule()

    def toggle(self):
        self.playing = not self.playing
        self.pp.set_icon_name("media-playback-pause-symbolic" if self.playing
                              else "media-playback-start-symbolic")
        if self.playing:
            self._schedule()
        else:
            self._cancel()

    def _show_bar(self):
        self.rev.set_reveal_child(True)
        self.set_cursor(None)
        if self._hide:
            GLib.source_remove(self._hide)
        self._hide = GLib.timeout_add_seconds(3, self._hide_bar)

    def _hide_bar(self):
        self._hide = 0
        self.rev.set_reveal_child(False)
        self.set_cursor_from_name("none")
        return False

    def _cancel(self):
        if self._timer:
            GLib.source_remove(self._timer)
            self._timer = 0

    def _schedule(self, delay=None):
        self._cancel()
        self._timer = GLib.timeout_add_seconds(delay or self.secs, self._tick)

    def _tick(self):
        self._timer = 0
        if self.playing:
            self.go(1)
        return False

    def _on_close(self, *_):
        self._cancel()
        if self._hide:
            GLib.source_remove(self._hide)
            self._hide = 0
        return False

    # --- przejście do następnego/poprzedniego zdjęcia (pomija filmy) ---
    def go(self, step):
        n = self.store.get_n_items()
        if n == 0:
            return
        if self.i > n - 10 and not self.win.exhausted:
            self.win.load_more()  # doładuj dalszą część albumu
        j = self.i
        for _ in range(n + 1):
            j += step
            if j >= n:
                if not self.win.exhausted:  # jeszcze się ładuje - spróbuj za chwilę
                    self._schedule(1)
                    return
                j = 0  # pętla od początku
            if j < 0:
                j = n - 1
            if not self.store.get_item(j).is_video:
                break
        self.show(j)

    def show(self, j):
        self.token += 1
        token = self.token
        obj = self.store.get_item(j)
        self._cancel()

        def work():
            return make_texture(self.win.icloud.fetch(obj.asset, "medium"))

        def done(tex, err):
            if token != self.token:
                return
            if err:
                log.warning("pokaz: pomijam %s: %r", obj.asset.filename, err)
                self.i = j
                if self.playing:
                    self._schedule(1)
                return
            self.i = j
            nxt = 1 - self.front
            self.pics[nxt].set_paintable(tex)
            self.stack.set_visible_child_name(str(nxt))
            self.front = nxt
            n = self.store.get_n_items()
            more = "+" if not self.win.exhausted else ""
            self.caption.set_text(f"{obj.asset.filename}   ({j + 1}/{n}{more})")
            self.win.cast_asset(obj.asset)
            if self.playing:
                self._schedule()
            for k in (j + 1, j + 2):
                if k < n and not self.store.get_item(k).is_video:
                    POOL.submit(self._safe_fetch, self.store.get_item(k).asset)

        bg(work, done)

    def _safe_fetch(self, asset):
        try:
            self.win.icloud.fetch(asset, "medium")
        except Exception:  # noqa: BLE001
            pass


class UploadDialog(Gtk.Window):
    """Wysyłanie plików z komputera do iCloud z wyborem albumu."""

    def __init__(self, win, paths):
        super().__init__(transient_for=win, modal=True, title="Prześlij do iCloud")
        self.win = win
        self.paths = paths
        self._cancel = False
        self._running = False
        self.set_default_size(440, -1)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        for m in ("top", "bottom", "start", "end"):
            getattr(box, f"set_margin_{m}")(18)
        names = ", ".join(os.path.basename(p) for p in paths[:3])
        if len(paths) > 3:
            names += f" … (+{len(paths) - 3})"
        title = Gtk.Label(label=f"Pliki do wysłania: {len(paths)}", xalign=0)
        title.add_css_class("heading")
        sub = Gtk.Label(label=names, xalign=0, wrap=True)
        sub.add_css_class("dim-label")
        sub.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        box.append(title)
        box.append(sub)
        box.append(Gtk.Label(label="Dodaj do albumu:", xalign=0))
        self.names = ["Tylko biblioteka (bez albumu)"] + [n for n, _ in win.user_albums]
        self.dd = Gtk.DropDown.new_from_strings(self.names)
        for k, (n, _a) in enumerate(win.user_albums):
            if n == win.cur_title:
                self.dd.set_selected(k + 1)  # domyślnie bieżący album
        box.append(self.dd)
        self.prog = Gtk.ProgressBar()
        self.prog.set_visible(False)
        self.status = Gtk.Label(wrap=True, xalign=0, selectable=True)
        self.status.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        box.append(self.prog)
        box.append(self.status)
        row = Gtk.Box(spacing=8, halign=Gtk.Align.END)
        self.btn_cancel = Gtk.Button(label="Anuluj")
        self.btn_go = Gtk.Button(label="Prześlij")
        self.btn_go.add_css_class("suggested-action")
        self.btn_cancel.connect("clicked", self._on_cancel)
        self.btn_go.connect("clicked", self._go)
        row.append(self.btn_cancel)
        row.append(self.btn_go)
        box.append(row)
        self.set_child(box)

    def _on_cancel(self, *_):
        self._cancel = True
        if not self._running:
            self.close()

    def _go(self, *_):
        idx = self.dd.get_selected()
        album = None if idx == 0 else self.win.user_albums[idx - 1][1]
        album_name = None if idx == 0 else self.win.user_albums[idx - 1][0]
        self._running = True
        self.btn_go.set_sensitive(False)
        self.dd.set_sensitive(False)
        self.prog.set_visible(True)
        total = len(self.paths)
        self.status.set_text(f"Wysyłanie 0/{total}…")

        def progress(k):
            self.prog.set_fraction(k / total)
            self.status.set_text(f"Wysyłanie {k}/{total}…")
            return False

        def work():
            ok, errs = 0, []
            for k, path in enumerate(self.paths):
                if self._cancel:
                    break
                try:
                    self.win.icloud.upload(path, album)
                    ok += 1
                except Exception as e:  # noqa: BLE001
                    errs.append(f"{os.path.basename(path)}: {e}")
                    log.error("upload %s: %r", path, e)
                GLib.idle_add(progress, k + 1)
            return ok, errs

        def done(res, err):
            self._running = False
            ok, errs = res if res else (0, [str(err)])
            text = f"Wysłano {ok} z {total}."
            if errs:
                text += "\nBłędy:\n" + "\n".join(errs[:6])
            self.status.set_text(text)
            self.btn_cancel.set_label("Zamknij")
            self.btn_cancel.set_sensitive(True)
            if ok:
                self.win.after_upload(album_name)

        bg(work, done)


def _fmt_dt(dt):
    try:
        return dt.astimezone().strftime("%d.%m.%Y  %H:%M")
    except Exception:  # noqa: BLE001
        return "-"


def _fmt_size(n):
    if not n:
        return "-"
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


class InfoDialog(Gtk.Window):
    """Informacje o zdjęciu: nazwa, daty, rozmiar, lokalizacja, aparat/telefon (EXIF)."""

    def __init__(self, win, obj):
        super().__init__(transient_for=win, title="Informacje o zdjęciu")
        self.win = win
        self.obj = obj
        self.lat_lon = None
        self.set_default_size(440, -1)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        for m in ("top", "bottom", "start", "end"):
            getattr(box, f"set_margin_{m}")(18)
        self.grid = Gtk.Grid(column_spacing=14, row_spacing=8)
        self.row = 0
        box.append(self.grid)
        self.extra = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.append(self.extra)
        self.set_child(box)

        info = win.icloud.asset_info(obj.asset)
        kind = "Wideo" if info.get("video") else ("Live Photo" if info.get("live") else "Zdjęcie")
        self._add("Nazwa pliku", info.get("filename", "-"))
        self._add("Typ", kind)
        if info.get("asset_date"):
            self._add("Data wykonania", _fmt_dt(info["asset_date"]))
        if info.get("added_date"):
            self._add("Dodano do iCloud", _fmt_dt(info["added_date"]))
        w, h = (info.get("dimensions") or (None, None))
        if w and h:
            self._add("Wymiary", f"{w} × {h}  ({w * h / 1e6:.1f} MP)")
        if info.get("size"):
            self._add("Rozmiar oryginału", _fmt_size(info["size"]))
        if info.get("gps"):
            self._add_location(*info["gps"])
        if info.get("video"):
            return
        self.cam = Gtk.Label(label="Dane aparatu: wczytuję…", xalign=0)
        self.cam.add_css_class("dim-label")
        self.extra.append(self.cam)
        bg(lambda: win.icloud.read_exif(obj.asset), lambda r, e: self._exif_done(r, e, False))

    def _add(self, key, value):
        k = Gtk.Label(label=key, xalign=0, yalign=0)
        k.add_css_class("dim-label")
        v = Gtk.Label(label=str(value), xalign=0, selectable=True, wrap=True)
        v.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        v.set_max_width_chars(40)
        self.grid.attach(k, 0, self.row, 1, 1)
        self.grid.attach(v, 1, self.row, 1, 1)
        self.row += 1
        return v

    def _add_location(self, lat, lon):
        if self.lat_lon:
            return
        self.lat_lon = (lat, lon)
        self._add("Lokalizacja", f"{lat:.5f}, {lon:.5f}")
        link = Gtk.LinkButton.new_with_label(
            f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=15/{lat}/{lon}",
            "Pokaż na mapie (OpenStreetMap)")
        link.set_halign(Gtk.Align.START)
        name_btn = Gtk.Button(label="Pokaż nazwę miejsca")
        name_btn.set_halign(Gtk.Align.START)
        name_btn.set_tooltip_text("Wysyła współrzędne do OpenStreetMap (Nominatim)")

        def go(_b):
            name_btn.set_sensitive(False)
            name_btn.set_label("Szukam…")
            bg(lambda: self.win.icloud.reverse_geocode(lat, lon), done)

        def done(res, err):
            name_btn.set_visible(False)
            lbl = Gtk.Label(label=res or f"Nie udało się: {err}", xalign=0, wrap=True,
                            selectable=True)
            lbl.set_max_width_chars(44)
            self.extra.append(lbl)

        name_btn.connect("clicked", go)
        self.extra.append(link)
        self.extra.append(name_btn)

    def _exif_done(self, res, err, from_original):
        if hasattr(self, "orig_btn"):
            self.orig_btn.set_visible(False)
        if err:
            self.cam.set_text(f"Nie udało się wczytać danych aparatu: {err}")
            return
        res = res or {}
        cam = " ".join(x for x in (res.get("Make"), res.get("Model")) if x)
        if res.get("Make") and res.get("Model", "").startswith(res["Make"]):
            cam = res["Model"]
        if not cam and not res:
            self.cam.set_text("Podgląd z iCloud nie zawiera danych aparatu."
                              if not from_original else "Oryginał nie zawiera danych EXIF.")
            if not from_original:
                self.orig_btn = Gtk.Button(label="Wczytaj z oryginału (większy plik)")
                self.orig_btn.set_halign(Gtk.Align.START)

                def go(_b):
                    self.orig_btn.set_sensitive(False)
                    self.cam.set_text("Pobieram oryginał…")
                    bg(lambda: self.win.icloud.read_exif(self.obj.asset, original=True),
                       lambda r, e: self._exif_done(r, e, True))

                self.orig_btn.connect("clicked", go)
                self.extra.append(self.orig_btn)
            return
        self.cam.set_visible(False)
        if cam:
            self._add("Telefon / aparat", cam)
        if res.get("LensModel"):
            self._add("Obiektyw", res["LensModel"])
        exp = ", ".join(str(res[k]) for k in ("FNumber", "ExposureTime", "FocalLength")
                        if k in res)
        if res.get("ISO"):
            exp += (", " if exp else "") + f"ISO {res['ISO']}"
        if exp:
            self._add("Ekspozycja", exp)
        if res.get("DateTimeOriginal"):
            self._add("Data (EXIF)", res["DateTimeOriginal"])
        if res.get("gps"):
            self._add_location(*res["gps"])


SMART_PL = {
    "All Photos": ("Wszystkie zdjęcia", "image-x-generic-symbolic"),
    "Favorites": ("Ulubione", "starred-symbolic"),
    "Videos": ("Wideo", "camera-video-symbolic"),
    "Live": ("Live Photos", "media-playback-start-symbolic"),
    "Screenshots": ("Zrzuty ekranu", "camera-photo-symbolic"),
    "Selfies": ("Selfie", "avatar-default-symbolic"),
    "Portrait": ("Portrety", "avatar-default-symbolic"),
    "Panoramas": ("Panoramy", "image-x-generic-symbolic"),
    "Bursts": ("Serie", "view-grid-symbolic"),
    "Slo-mo": ("Slow-motion", "camera-video-symbolic"),
    "Time-lapse": ("Poklatkowe", "camera-video-symbolic"),
    "Long Exposure": ("Długa ekspozycja", "image-x-generic-symbolic"),
    "Animated": ("Animacje", "image-x-generic-symbolic"),
    "Hidden": ("Ukryte", "view-conceal-symbolic"),
    "Recently Deleted": ("Ostatnio usunięte", "user-trash-symbolic"),
}
PRIMARY = ("All Photos", "Favorites", "Videos", "Live", "Screenshots")
MORE_ORDER = ("Selfies", "Portrait", "Panoramas", "Bursts", "Slo-mo", "Time-lapse",
              "Long Exposure", "Animated", "Hidden", "Recently Deleted")


class PairingDialog(Gtk.Window):
    """Parowanie z odbiornikiem AirPlay (Apple TV): kod PIN pojawia się na ekranie telewizora."""

    def __init__(self, win, target, on_done):
        super().__init__(transient_for=win, modal=True, title=f"Parowanie: {target.name}")
        self.win, self.target, self.on_done = win, target, on_done
        self.set_default_size(380, -1)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        for m in ("top", "bottom", "start", "end"):
            getattr(box, f"set_margin_{m}")(18)
        box.append(Gtk.Label(label="Na ekranie telewizora pojawi się kod PIN.\nWpisz go poniżej.",
                             xalign=0, wrap=True))
        self.entry = Gtk.Entry(placeholder_text="PIN", max_length=8)
        self.entry.set_sensitive(False)
        self.entry.connect("activate", self._go)
        self.status = Gtk.Label(label="Łączę z urządzeniem…", xalign=0, wrap=True,
                                selectable=True)
        self.status.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        row = Gtk.Box(spacing=8, halign=Gtk.Align.END)
        cancel = Gtk.Button(label="Anuluj")
        cancel.connect("clicked", lambda *_: self.close())
        self.go_btn = Gtk.Button(label="Sparuj")
        self.go_btn.add_css_class("suggested-action")
        self.go_btn.set_sensitive(False)
        self.go_btn.connect("clicked", self._go)
        row.append(cancel)
        row.append(self.go_btn)
        for w in (self.entry, self.status, row):
            box.append(w)
        self.set_child(box)
        bg(target.pair_begin, self._started)

    def _started(self, shows_pin, err):
        if err:
            log.error("AirPlay pair_begin: %r", err)
            self.status.set_text(f"Nie udało się rozpocząć parowania: {err}")
            return
        self.status.set_text("Wpisz PIN z ekranu TV." if shows_pin
                             else "Urządzenie nie pokazuje PIN-u - wpisz kod, którego oczekuje.")
        self.entry.set_sensitive(True)
        self.go_btn.set_sensitive(True)
        self.entry.grab_focus()

    def _go(self, *_):
        pin = self.entry.get_text().strip()
        if not pin:
            return
        self.go_btn.set_sensitive(False)
        self.status.set_text("Parowanie…")
        bg(lambda: self.target.pair_finish(pin), self._finished)

    def _finished(self, ok, err):
        if err or not ok:
            log.error("AirPlay pair_finish: %r", err)
            self.status.set_text(f"Zły PIN albo błąd parowania: {err or ''}")
            self.go_btn.set_sensitive(True)
            return
        self.close()
        self.on_done()


class AlbumRow(Gtk.ListBoxRow):
    def __init__(self, title, icon, album, key=None, cover=False, static=False, bold=False):
        super().__init__()
        self.album = album
        self.title = title
        self.key = key or title
        self.thumb = None
        box = Gtk.Box(spacing=10)
        box.set_margin_top(5 if cover else 6)
        box.set_margin_bottom(5 if cover else 6)
        box.set_margin_start(8)
        box.set_margin_end(8)
        self.icon = Gtk.Image.new_from_icon_name(icon)
        if cover:  # kafelek 40x40: okładka albumu albo (static) duża ikona
            self.thumb = Gtk.Image()
            self.thumb.set_pixel_size(40)
            ov = Gtk.Overlay()
            self.cover_box = ov
            ov.set_child(self.thumb)
            ov.set_size_request(40, 40)
            ov.set_halign(Gtk.Align.START)
            ov.set_valign(Gtk.Align.CENTER)
            ov.set_hexpand(False)
            ov.add_css_class("albumcover")
            ov.set_overflow(Gtk.Overflow.HIDDEN)
            self.icon.set_halign(Gtk.Align.CENTER)
            self.icon.set_valign(Gtk.Align.CENTER)
            if static:
                self.icon.set_pixel_size(26)
                self.thumb = None  # nigdy nie podmieniaj ikony na zdjęcie
            ov.add_overlay(self.icon)
            box.append(ov)
        else:
            box.append(self.icon)
        lbl = Gtk.Label(label=title, xalign=0, hexpand=True)
        lbl.set_ellipsize(3)  # END
        if bold:
            lbl.add_css_class("heading")
        self.lbl = lbl
        box.append(lbl)
        self.set_child(box)

    def set_cover(self, tex):
        if self.thumb is not None:
            self.thumb.set_from_paintable(tex)
            self.icon.set_visible(False)


class MainWindow(Adw.ApplicationWindow):
    def __init__(self, app, icloud=None, autologin=True):
        super().__init__(application=app, title="iCloud Photos")
        self.set_default_size(1200, 780)
        self.icloud = icloud or ICloud()
        self.tex = TexCache()
        self.store = Gio.ListStore(item_type=PhotoObj)
        self.pending_2fa = False
        self.gen = 0
        self.total = None
        cfg = load_cfg()
        self.tile_size = max(TILE_MIN, min(TILE_MAX, int(cfg.get("tile", TILE_DEFAULT))))
        self.tiles = weakref.WeakSet()
        self._tguard = False
        self.newest_first = bool(cfg.get("newest_first", True))
        self.flips = {}            # tytuł albumu -> czy odwrócić założony kierunek
        self.cur_album = None
        self.cur_title = ""
        self.it = None
        self.exhausted = True
        self.loading = False
        self._auto_fixed = False
        self.cast_target = None
        self.last_obj = None
        self.fit_original = bool(cfg.get("fit_original", False))
        self._rebuild_src = 0
        self._split_src = 0
        self._pguard = False
        self._last_cast_err = ("", 0.0)
        self.user_albums = []
        self.slide_secs = int(cfg.get("slide_secs", 5))
        self.embedded_video = (os.environ.get("ICLOUD_PHOTOS_EMBEDDED_VIDEO") == "1"
                               or bool(cfg.get("embedded_video", False)))

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.header = Adw.HeaderBar()
        self.wtitle = Adw.WindowTitle(title="iCloud Photos", subtitle="")
        self.header.set_title_widget(self.wtitle)
        self.sidebar_btn = Gtk.ToggleButton(icon_name="sidebar-show-symbolic")
        self.sidebar_btn.set_visible(False)
        self.header.pack_start(self.sidebar_btn)
        self.count = Gtk.Label()
        self.header.pack_end(self.count)

        # zoom miniatur: − [suwak] +
        self.zoom_box = Gtk.Box(spacing=2)
        b_out = Gtk.Button(icon_name="zoom-out-symbolic")
        b_out.add_css_class("flat")
        b_out.set_tooltip_text("Mniejsze miniatury (Ctrl −)")
        b_out.connect("clicked", lambda *_: self.set_tile_size(self.tile_size - 20))
        self.tile_scale = Gtk.Scale.new_with_range(
            Gtk.Orientation.HORIZONTAL, TILE_MIN, TILE_MAX, 10)
        self.tile_scale.set_draw_value(False)
        self.tile_scale.set_size_request(130, -1)
        self.tile_scale.set_value(self.tile_size)
        self.tile_scale.connect("value-changed", self._on_tile_scale)
        b_in = Gtk.Button(icon_name="zoom-in-symbolic")
        b_in.add_css_class("flat")
        b_in.set_tooltip_text("Większe miniatury (Ctrl +)")
        b_in.connect("clicked", lambda *_: self.set_tile_size(self.tile_size + 20))
        for w in (b_out, self.tile_scale, b_in):
            self.zoom_box.append(w)
        self.header.pack_end(self.zoom_box)

        # tryby widoku siatki (jak w Google Photos): małe / standardowe / duże / bardzo duże
        self.view_btn = Gtk.MenuButton(icon_name="view-grid-symbolic")
        self.view_btn.set_tooltip_text("Widok siatki")
        vpop = Gtk.Popover()
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        for m in ("top", "bottom", "start", "end"):
            getattr(vbox, f"set_margin_{m}")(8)
        self.presets = []
        first = None
        for label, size in PRESETS:
            cb = Gtk.CheckButton(label=f"{label}")
            if first is None:
                first = cb
            else:
                cb.set_group(first)
            cb.connect("toggled", lambda b, size=size: b.get_active()
                       and not self._pguard and self.set_tile_size(size))
            vbox.append(cb)
            self.presets.append((cb, size))
        vbox.append(Gtk.Separator())
        self.fit_check = Gtk.CheckButton(label="Oryginalne proporcje (bez przycinania)")
        self.fit_check.set_active(self.fit_original)
        self.fit_check.connect("toggled", self._on_fit_toggled)
        vbox.append(self.fit_check)
        vpop.set_child(vbox)
        self.view_btn.set_popover(vpop)
        self.header.pack_end(self.view_btn)
        self._sync_presets()

        # sortowanie, dodawanie plików, PLAY (pokaz slajdów), wysyłka na TV
        self.sort_btn = Gtk.Button()
        self.sort_btn.add_css_class("flat")
        self.sort_btn.connect("clicked", self._toggle_sort)
        self._update_sort_btn()
        self.add_btn = Gtk.Button(icon_name="list-add-symbolic")
        self.add_btn.set_tooltip_text(
            "Dodaj zdjęcia do iCloud (możesz też przeciągnąć pliki do okna)")
        self.add_btn.connect("clicked", self._choose_files)
        self.slide_btn = Gtk.Button(icon_name="media-playback-start-symbolic")
        self.slide_btn.set_tooltip_text("Pokaz slajdów bieżącego albumu (PLAY)")
        self.slide_btn.add_css_class("suggested-action")
        self.slide_btn.connect("clicked", self._start_slideshow)
        self.info_btn = Gtk.Button(icon_name="dialog-information-symbolic")
        self.info_btn.add_css_class("flat")
        self.info_btn.set_tooltip_text(
            "Informacje o zdjęciu (ostatnio otwartym lub klikniętym prawym przyciskiem)")
        self.info_btn.connect("clicked", self._info_clicked)
        for b in (self.sort_btn, self.add_btn, self.slide_btn, self.info_btn):
            self.header.pack_start(b)
        self._build_cast()
        self.header.pack_end(self.cast_btn)
        self.logged_widgets = [self.zoom_box, self.view_btn, self.sort_btn, self.add_btn,
                               self.slide_btn, self.info_btn, self.cast_btn]
        for w in self.logged_widgets:
            w.set_visible(False)
        box.append(self.header)

        self.stack = Gtk.Stack()
        self.stack.set_vexpand(True)
        self.stack.add_named(self._build_login(), "login")
        self.stack.add_named(self._build_main(), "main")
        box.append(self.stack)
        self.toasts = Adw.ToastOverlay()
        self.toasts.set_child(box)
        self.set_content(self.toasts)

        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self._on_key)
        self.add_controller(keys)
        dt = Gtk.DropTarget.new(Gdk.FileList, Gdk.DragAction.COPY)
        dt.connect("drop", self._on_drop)
        self.add_controller(dt)

        if autologin:
            self._autologin()

    # --- logowanie ---
    def _build_login(self):
        clamp = Adw.Clamp(maximum_size=380)
        v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        v.set_valign(Gtk.Align.CENTER)
        title = Gtk.Label(label="Zaloguj się do iCloud")
        title.add_css_class("title-2")
        self.e_id = Gtk.Entry(placeholder_text="Apple ID (e-mail)")
        self.e_pw = Gtk.PasswordEntry(placeholder_text="Hasło", show_peek_icon=True)
        self.e_code = Gtk.Entry(placeholder_text="Kod 2FA (6 cyfr)")
        self.e_code.set_visible(False)
        self.btn = Gtk.Button(label="Zaloguj")
        self.btn.add_css_class("suggested-action")
        self.status = Gtk.Label(wrap=True, xalign=0, selectable=True)
        self.status.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        self.btn_copy = Gtk.Button(label="Kopiuj błąd")
        self.btn_copy.set_visible(False)
        self.btn_copy.connect("clicked", self._copy_status)
        for w in (title, self.e_id, self.e_pw, self.e_code, self.btn, self.status,
                  self.btn_copy):
            v.append(w)
        self.btn.connect("clicked", self.on_login)
        self.e_pw.connect("activate", self.on_login)
        self.e_code.connect("activate", self.on_login)
        clamp.set_child(v)
        return clamp

    def _autologin(self):
        apple_id = None
        try:
            apple_id = json.loads(CONFIG_FILE.read_text()).get("apple_id")
        except Exception:  # noqa: BLE001
            pass
        pw = None
        if apple_id and keyring:
            try:
                pw = keyring.get_password(KEYRING_SERVICE, apple_id)
            except Exception:  # noqa: BLE001
                pass
        if apple_id:
            self.e_id.set_text(apple_id)
        self.stack.set_visible_child_name("login")
        if apple_id and pw:
            self.e_pw.set_text(pw)
            self.say("Logowanie z zapisanej sesji…")
            bg(lambda: self.icloud.login(apple_id, pw), self._after_login)

    def say(self, text, error=False):
        """Komunikat na ekranie logowania; błędy można zaznaczyć i skopiować."""
        self.status.set_text(text)
        self.btn_copy.set_visible(error)

    def _copy_status(self, *_):
        self.get_clipboard().set(self.status.get_text())
        self.btn_copy.set_label("Skopiowano ✓")
        GLib.timeout_add_seconds(2, lambda: (self.btn_copy.set_label("Kopiuj błąd"), False)[1])

    @staticmethod
    def _describe(err):
        text = f"{type(err).__name__}: {err}"
        if "503" in text:
            text += ("\n\nApple chwilowo odrzuca logowanie (503 Service Temporarily "
                     "Unavailable). Odczekaj kilkanaście minut i spróbuj raz - "
                     "wielokrotne próby mogą wydłużyć blokadę.")
        return text

    def on_login(self, *_):
        self.btn.set_sensitive(False)
        if self.pending_2fa:
            code = self.e_code.get_text()
            self.say("Weryfikacja kodu…")
            bg(lambda: self.icloud.verify_2fa(code), self._after_2fa)
            return
        aid, pw = self.e_id.get_text().strip(), self.e_pw.get_text()
        if not aid or not pw:
            self.say("Podaj Apple ID i hasło.")
            self.btn.set_sensitive(True)
            return
        self.say("Logowanie…")
        bg(lambda: self.icloud.login(aid, pw), self._after_login)

    def _after_login(self, state, err):
        self.btn.set_sensitive(True)
        if err:
            self.say("Błąd logowania: " + self._describe(err), True)
        elif state == "2fa":
            self.pending_2fa = True
            self.e_code.set_visible(True)
            self.e_code.grab_focus()
            self.say("Wpisz kod z zaufanego urządzenia Apple.")
        else:
            self.logged_in()

    def _after_2fa(self, ok, err):
        self.btn.set_sensitive(True)
        if err or not ok:
            self.say("Błąd: zły kod albo problem z weryfikacją: " + (self._describe(err) if err else ""), True)
        else:
            self.pending_2fa = False
            self.logged_in()

    def logged_in(self, save=True):
        aid, pw = self.e_id.get_text().strip(), self.e_pw.get_text()
        if save and aid:
            save_cfg(apple_id=aid)
            try:
                if keyring and pw:
                    keyring.set_password(KEYRING_SERVICE, aid, pw)
            except Exception:  # noqa: BLE001
                pass
        self.e_pw.set_text("")
        for w in self.logged_widgets:
            w.set_visible(True)
        self.stack.set_visible_child_name("main")
        self.sidebar_btn.set_visible(True)
        self.say("")
        bg(self.icloud.albums, self._albums_loaded)

    # --- główny widok: menu albumów + siatka ---
    @staticmethod
    def _bold_label(text):
        lbl = Gtk.Label(label=text, xalign=0)
        lbl.add_css_class("heading")
        return lbl

    def _make_list(self):
        lb = Gtk.ListBox()
        lb.add_css_class("navigation-sidebar")
        lb.set_filter_func(self._row_filter)
        lb.connect("row-selected", self._on_album_selected)
        self.lists.append(lb)
        return lb

    def _build_main(self):
        self.lists = []
        self._busy = False
        # Gtk.Paned: separator, który można przeciągać (szerokość menu jest zapamiętywana)
        self.split = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.split.set_wide_handle(True)
        self.split.set_resize_start_child(False)
        self.split.set_shrink_start_child(False)
        self.split.set_resize_end_child(True)
        self.split.set_shrink_end_child(False)
        self.split.set_position(int(load_cfg().get("sidebar_w", 270)))
        self.split.connect("notify::position", self._on_split_pos)
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.search = Gtk.SearchEntry(placeholder_text="Szukaj albumu")
        self.search.set_margin_start(8)
        self.search.set_margin_end(8)
        self.search.set_margin_top(8)
        self.search.connect("search-changed", self._on_search)
        side.append(self.search)

        self.list_primary = self._make_list()
        side.append(self.list_primary)
        self.list_more = self._make_list()
        self.exp_more = Gtk.Expander()
        self.exp_more.set_label_widget(self._bold_label("Typy mediów"))
        self.exp_more.set_child(self.list_more)
        self.exp_more.set_margin_start(8)
        self.exp_more.set_visible(False)
        side.append(self.exp_more)
        self.list_user = self._make_list()
        self.exp_user = Gtk.Expander()
        self.exp_user_lbl = self._bold_label("Moje albumy")
        self.exp_user.set_label_widget(self.exp_user_lbl)
        self.exp_user.set_child(self.list_user)
        self.exp_user.set_margin_start(8)
        self.exp_user.set_visible(False)
        side.append(self.exp_user)

        scroller = Gtk.ScrolledWindow()
        scroller.set_child(side)
        scroller.set_vexpand(True)
        side_col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        side_col.set_size_request(170, -1)
        side_col.append(scroller)
        ver = Gtk.Label(label=f"v{VERSION}  ·  {DATE}", xalign=0)
        ver.add_css_class("dim-label")
        ver.add_css_class("caption")
        for m in ("start", "end", "top", "bottom"):
            getattr(ver, f"set_margin_{m}")(8)
        side_col.append(ver)
        self.sidebar_scroller = side_col
        self.split.set_start_child(side_col)
        self.split.set_end_child(self._build_grid())
        side_col.bind_property(
            "visible", self.sidebar_btn, "active",
            GObject.BindingFlags.BIDIRECTIONAL | GObject.BindingFlags.SYNC_CREATE)
        return self.split

    def _on_split_pos(self, *_):
        if self._split_src:
            GLib.source_remove(self._split_src)

        def save():
            self._split_src = 0
            if self.sidebar_scroller.get_visible():
                save_cfg(sidebar_w=self.split.get_position())
            return False

        self._split_src = GLib.timeout_add(600, save)

    def _row_filter(self, row):
        q = self.search.get_text().strip().lower() if hasattr(self, "search") else ""
        return not q or q in row.title.lower()

    def _on_search(self, entry):
        for lb in self.lists:
            lb.invalidate_filter()
        if entry.get_text().strip():
            self.exp_more.set_expanded(True)
            self.exp_user.set_expanded(True)

    def _albums_loaded(self, albums, err):
        if err:
            self.count.set_text(f"Błąd albumów: {err}")
            return
        by_name = dict(albums)
        cover_rows = []
        for key in PRIMARY:
            if key in by_name:
                title, icon = SMART_PL[key]
                static = key in ("Favorites", "Videos")  # gwiazdka / kamera zamiast zdjęcia
                row = AlbumRow(title, icon, by_name[key], key=key, cover=True,
                               static=static, bold=(key == "All Photos"))
                self.list_primary.append(row)
                if not static:
                    cover_rows.append(row)
        more = [k for k in MORE_ORDER if k in by_name]
        for key in more:
            title, icon = SMART_PL[key]
            self.list_more.append(AlbumRow(title, icon, by_name[key], key=key))
        self.exp_more.set_visible(bool(more))
        users = sorted(((n, a) for n, a in albums if n not in SMART_PL),
                       key=lambda t: t[0].lower())
        self.user_albums = users
        for name, album in users:
            row = AlbumRow(name, "folder-pictures-symbolic", album, key=name, cover=True)
            self.list_user.append(row)
            cover_rows.append(row)
        self.exp_user_lbl.set_text(f"Moje albumy ({len(users)})")
        self.exp_user.set_visible(bool(users))
        first = self.list_primary.get_row_at_index(0)
        if first:
            self.list_primary.select_row(first)
        GLib.timeout_add_seconds(2, lambda: (self._load_covers(cover_rows), False)[1])

    def _load_covers(self, rows):
        def work(row):
            last = None
            for k in range(3):  # chwilowe błędy / limity Apple - ponów z odstępem
                try:
                    return make_square_texture(self.icloud.album_cover(row.key, row.album))
                except LookupError:
                    raise
                except Exception as e:  # noqa: BLE001
                    last = e
                    time.sleep(2 * (k + 1))
            raise last

        for row in rows:
            fut = COVER_POOL.submit(work, row)

            def done(f, row=row):
                if f.cancelled():
                    return
                if f.exception():
                    log.warning("okładka albumu %r: %r", row.title, f.exception())
                    return
                GLib.idle_add(lambda: (row.set_cover(f.result()), False)[1])

            fut.add_done_callback(done)

    def _on_album_selected(self, lb, row):
        if row is None or self._busy:
            return
        self._busy = True  # tylko jedna zaznaczona pozycja w całym menu
        for other in self.lists:
            if other is not lb:
                other.unselect_all()
        self._busy = False
        self.wtitle.set_title(row.title)
        self.cur_title = row.title
        self.load_album(row.album)

    def _build_grid(self):
        self.grid = Gtk.GridView(model=Gtk.NoSelection(model=self.store),
                                 factory=self._make_factory())
        self.grid.set_single_click_activate(True)
        self.grid.set_min_columns(2)
        self.grid.set_max_columns(24)
        self.grid.connect("activate", self._on_activate)
        sw = Gtk.ScrolledWindow()
        sw.set_vexpand(True)
        sw.set_child(self.grid)
        sc = Gtk.EventControllerScroll.new(Gtk.EventControllerScrollFlags.VERTICAL)
        sc.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        sc.connect("scroll", self._on_grid_scroll)
        sw.add_controller(sc)
        self.grid_sw = sw
        adj = sw.get_vadjustment()
        adj.connect("value-changed", lambda *_: self._maybe_more())
        adj.connect("changed", lambda *_: self._maybe_more())
        return sw

    def _make_factory(self):
        f = Gtk.SignalListItemFactory()
        f.connect("setup", lambda _f, li: li.set_child(self._new_tile()))
        f.connect("bind", self._bind)
        f.connect("unbind", self._unbind)
        return f

    def _new_tile(self):
        t = Tile(self.tile_size)
        t.set_fit(self.fit_original)
        t.on_context = self._tile_context
        self.tiles.add(t)
        return t

    def _on_fit_toggled(self, cb):
        self.fit_original = cb.get_active()
        save_cfg(fit_original=self.fit_original)
        for t in list(self.tiles):
            t.set_fit(self.fit_original)

    def _rebuild_grid(self):
        """Wymusza przeliczenie całej siatki (pewniejsze niż same size_request)."""
        self._rebuild_src = 0
        self.grid.set_factory(self._make_factory())
        return False

    def _sync_presets(self):
        self._pguard = True
        for cb, size in self.presets:
            cb.set_active(size == self.tile_size)
        self._pguard = False

    def set_tile_size(self, n):
        n = int(max(TILE_MIN, min(TILE_MAX, n)))
        if n == self.tile_size:
            return
        self.tile_size = n
        for t in list(self.tiles):
            t.set_size(n)
        self._tguard = True
        self.tile_scale.set_value(n)
        self._tguard = False
        save_cfg(tile=n)
        log.info("rozmiar miniatur: %s", n)
        self._sync_presets()
        if self._rebuild_src:
            GLib.source_remove(self._rebuild_src)
        self._rebuild_src = GLib.timeout_add(250, self._rebuild_grid)

    def _on_tile_scale(self, sc):
        if not self._tguard:
            self.set_tile_size(round(sc.get_value() / 10) * 10)

    def _on_grid_scroll(self, ctrl, _dx, dy):
        if ctrl.get_current_event_state() & Gdk.ModifierType.CONTROL_MASK:
            self.set_tile_size(self.tile_size + (-10 if dy > 0 else 10))
            return True
        return False

    def _bind(self, _f, li):
        obj, tile = li.get_item(), li.get_child()
        tile.bound = obj
        tile.ph.set_visible(False)
        tile.vbadge.set_visible(obj.is_video)
        tile.lbadge.set_visible(obj.is_live)
        tex = self.tex.get(obj.asset.id)
        if tex is not None:
            tile.pic.set_paintable(tex)
            return
        tile.pic.set_paintable(None)

        def work():
            return make_texture(self.icloud.fetch(obj.asset, "thumb"))

        fut = POOL.submit(work)
        tile.future = fut

        def done(f):
            if f.cancelled():
                return
            if f.exception():
                GLib.idle_add(self._tile_failed, tile, obj)
                return
            GLib.idle_add(self._apply, tile, obj, f.result())

        fut.add_done_callback(done)

    def _apply(self, tile, obj, tex):
        self.tex.put(obj.asset.id, tex)
        if tile.bound is obj:
            tile.ph.set_visible(False)
            tile.pic.set_paintable(tex)
        return False

    def _tile_failed(self, tile, obj):
        if tile.bound is obj:
            tile.ph.set_from_icon_name(
                "camera-video-symbolic" if obj.is_video else "image-missing-symbolic")
            tile.ph.set_visible(True)
        return False

    def _unbind(self, _f, li):
        tile = li.get_child()
        tile.bound = None
        if tile.future is not None:
            tile.future.cancel()
            tile.future = None
        tile.pic.set_paintable(None)

    def _on_activate(self, _grid, pos):
        obj = self.store.get_item(pos)
        if obj.is_video and self.cast_target is not None:
            self.cast_asset(obj.asset)
            return
        if obj.is_video and self.external_video_ok():
            self.play_external(obj)
            return
        self._viewer = Viewer(self, pos)
        self._viewer.present()

    # --- ładowanie albumu ---
    def load_album(self, album, _auto=False):
        v = getattr(self, "_viewer", None)
        if v is not None:  # lista się przeładuje - zamknij otwarty podgląd
            v.close()
            self._viewer = None
        self.gen += 1
        gen = self.gen
        self.cur_album = album
        self.total = None
        self.exhausted = False
        self.loading = False
        self._auto_fixed = _auto
        flip = self.flips.get(self.cur_title, False)
        self.it = self.icloud.iter_assets(album, self.newest_first, flip)
        self.store.remove_all()
        self.count.set_text("…")
        bg(lambda: self.icloud.total(album), lambda t, e: self._set_total(gen, t))
        self._load_more(gen)

    def _set_total(self, gen, total):
        if gen == self.gen and total:
            self.total = total
            self._update_count()

    def load_more(self):
        self._load_more()

    def _load_more(self, gen=None):
        """Dociąga kolejną porcję (BATCH) zdjęć. Wołane przy przewijaniu."""
        gen = self.gen if gen is None else gen
        if self.loading or self.exhausted or gen != self.gen or self.it is None:
            return
        self.loading = True
        it = self.it

        def work():
            batch = []
            for asset in it:
                batch.append(PhotoObj(asset, self.icloud.is_video(asset),
                                      self.icloud.is_live(asset)))
                if len(batch) >= BATCH:
                    return batch, False
            return batch, True  # iterator się skończył

        def done(res, err):
            if gen != self.gen:
                return
            self.loading = False
            if err:
                self.exhausted = True
                log.error("lista albumu %r: %r", self.cur_title, err)
                self.count.set_text(f"Błąd listy: {err}")
                return
            batch, finished = res
            if batch and self.store.get_n_items() == 0 and self._check_order(batch):
                return  # kolejność była odwrotna - album załadowany ponownie
            if batch:
                self.store.splice(self.store.get_n_items(), 0, batch)
            self.exhausted = finished
            self._update_count()
            GLib.timeout_add(200, self._maybe_more)

        bg(work, done)

    def _check_order(self, batch):
        """Sprawdza po datach pierwszej porcji, czy kolejność zgadza się z żądaniem.
        Jeśli nie - odwraca założenie dla tego albumu i ładuje go ponownie (raz)."""
        d0 = self.icloud.asset_date(batch[0].asset)
        d1 = self.icloud.asset_date(batch[-1].asset)
        log.info("album %r: newest_first=%s flip=%s pierwszy=%s ostatni_w_porcji=%s",
                 self.cur_title, self.newest_first, self.flips.get(self.cur_title, False),
                 d0, d1)
        if self._auto_fixed or len(batch) < 2 or not d0 or not d1 or d0 == d1:
            return False
        if (d0 > d1) != self.newest_first:
            self.flips[self.cur_title] = not self.flips.get(self.cur_title, False)
            log.warning("kolejność albumu %r odwrotna niż żądana - ładuję ponownie",
                        self.cur_title)
            self.load_album(self.cur_album, _auto=True)
            return True
        return False

    def _maybe_more(self, *_):
        if self.loading or self.exhausted or self.cur_album is None:
            return False
        adj = self.grid_sw.get_vadjustment()
        page, upper, val = adj.get_page_size(), adj.get_upper(), adj.get_value()
        if page > 0 and upper - (val + page) < 3 * page:
            self._load_more()
        return False

    def _update_count(self):
        n = self.store.get_n_items()
        if self.total:
            self.count.set_text(f"{n} / {self.total}")
        elif n:
            self.count.set_text(str(n))
        return False

    def _update_sort_btn(self):
        if self.newest_first:
            self.sort_btn.set_icon_name("view-sort-descending-symbolic")
            self.sort_btn.set_tooltip_text("Kolejność: najnowsze najpierw (kliknij, aby odwrócić)")
        else:
            self.sort_btn.set_icon_name("view-sort-ascending-symbolic")
            self.sort_btn.set_tooltip_text("Kolejność: najstarsze najpierw (kliknij, aby odwrócić)")

    def _toggle_sort(self, *_):
        self.newest_first = not self.newest_first
        save_cfg(newest_first=self.newest_first)
        self.flips.clear()
        self._update_sort_btn()
        if self.cur_album is not None:
            self.load_album(self.cur_album)

    # --- pokaz slajdów ---
    def _start_slideshow(self, *_):
        if self.store.get_n_items() == 0:
            self.toast("Album jest pusty albo jeszcze się ładuje")
            return
        Slideshow(self, 0).present()

    # --- wysyłanie na TV (DLNA/UPnP) ---
    def _build_cast(self):
        self.cast_btn = Gtk.MenuButton(icon_name="video-display-symbolic")
        self.cast_btn.set_tooltip_text("Wyślij na TV (DLNA/UPnP)")
        pop = Gtk.Popover()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        for m in ("top", "bottom", "start", "end"):
            getattr(box, f"set_margin_{m}")(12)
        head = Gtk.Label(label="Wyślij na TV (DLNA/UPnP)", xalign=0)
        head.add_css_class("heading")
        self.cast_status = Gtk.Label(xalign=0, wrap=True)
        self.cast_status.set_max_width_chars(36)
        self.cast_list = Gtk.ListBox()
        self.cast_list.add_css_class("boxed-list")
        self.cast_list.set_selection_mode(Gtk.SelectionMode.NONE)
        self.cast_list.connect("row-activated", self._cast_pick)
        rescan = Gtk.Button(label="Szukaj ponownie")
        rescan.connect("clicked", lambda *_: self._cast_scan())
        stop = Gtk.Button(label="Zatrzymaj wysyłanie")
        stop.connect("clicked", self._cast_stop)
        note = Gtk.Label(label="AirPlay: wideo po sparowaniu PIN-em; zdjęcia eksperymentalnie.",
                         xalign=0, wrap=True)
        note.set_max_width_chars(36)
        note.add_css_class("dim-label")
        for w in (head, self.cast_status, self.cast_list, rescan, stop, note):
            box.append(w)
        pop.set_child(box)
        self.cast_pop = pop
        pop.connect("show", lambda *_: self._cast_scan())
        self.cast_btn.set_popover(pop)

    def _cast_scan(self):
        self.cast_status.set_text("Szukam telewizorów w sieci…")
        child = self.cast_list.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self.cast_list.remove(child)
            child = nxt

        def done(found, err):
            if err or not found:
                self.cast_status.set_text(
                    "Nie znaleziono urządzeń DLNA w tej sieci. Upewnij się, że TV jest "
                    "włączony, w tej samej sieci, a DLNA/udostępnianie włączone."
                    + (f"\n{err}" if err else ""))
                return
            self.cast_status.set_text(f"Znaleziono: {len(found)}. Wybierz urządzenie:")
            for r in found:
                row = Gtk.ListBoxRow()
                row.renderer = r
                lbl = Gtk.Label(label=f"{r.name}   ·   {r.kind}", xalign=0)
                lbl.set_margin_top(8)
                lbl.set_margin_bottom(8)
                lbl.set_margin_start(10)
                lbl.set_margin_end(10)
                row.set_child(lbl)
                self.cast_list.append(row)

        bg(self._discover_all, done)

    @staticmethod
    def _discover_all():
        """DLNA/UPnP (LG, Samsung, Sony...) i Chromecast równolegle."""
        from concurrent.futures import ThreadPoolExecutor

        out = []
        with ThreadPoolExecutor(max_workers=3) as ex:
            futs = [ex.submit(dlna.discover), ex.submit(cast_gc.discover),
                    ex.submit(airplay.discover)]
            for f in futs:
                try:
                    out += f.result()
                except Exception as e:  # noqa: BLE001
                    log.warning("wykrywanie TV: %r", e)
        return out

    def _cast_pick(self, _lb, row):
        r = row.renderer
        self.cast_pop.popdown()
        if getattr(r, "needs_pairing", False):  # AirPlay: najpierw sparuj PIN-em z ekranu TV
            PairingDialog(self, r, lambda: self._set_cast_target(r)).present()
            return
        self._set_cast_target(r)

    def _set_cast_target(self, r):
        self.cast_target = r
        self.cast_btn.add_css_class("suggested-action")
        self.toast(f"Wysyłanie na: {r.name}. Otwórz zdjęcie lub włącz pokaz.")
        log.info("cast: wybrano %s (%s)", r.name, r.control_url)

    def _cast_stop(self, *_):
        r, self.cast_target = self.cast_target, None
        self.cast_btn.remove_css_class("suggested-action")
        self.cast_pop.popdown()
        if r is not None:
            bg(r.stop, lambda _res, _e: None)
            self.toast("Zatrzymano wysyłanie na TV")

    def cast_asset(self, asset):
        """Wysyła bieżące zdjęcie/wideo na wybrany TV (jeśli jakiś jest wybrany)."""
        r = self.cast_target
        if r is None:
            return
        is_vid = self.icloud.is_video(asset)
        if is_vid:
            ver, mime, fname = self.icloud.video_version(asset, True), "video/mp4", "video.mp4"
        else:
            jpg = asset.filename.lower().endswith((".jpg", ".jpeg"))
            ver = "original" if jpg and "original" in asset.versions else "medium"
            mime, fname = "image/jpeg", "photo.jpg"
        if ver is None:
            return

        def work():
            ip = self.icloud.lan_ip_for(r.host)
            url = self.icloud.stream_url(asset, ver, lan_host=ip) + "/" + fname
            r.play_uri(url, asset.filename, mime, is_vid)

        def done(_res, err):
            if err:
                msg = str(err)
                log.error("cast: %s", msg)
                last, ts = self._last_cast_err
                if msg != last or time.monotonic() - ts > 15:
                    self.toast("TV: " + msg)
                    self._last_cast_err = (msg, time.monotonic())

        bg(work, done)

    # --- wysyłanie plików do iCloud ---
    def _on_drop(self, _target, value, _x, _y):
        if self.stack.get_visible_child_name() != "main":
            return False
        paths = [f.get_path() for f in value.get_files() if f.get_path()]
        self._offer_upload(paths)
        return True

    def _offer_upload(self, paths):
        ok = [p for p in paths if p.lower().endswith(ICloud.UPLOAD_EXT)]
        if not ok:
            self.toast("Brak obsługiwanych plików (JPG, PNG, HEIC, GIF, TIFF, DNG, MOV, MP4)")
            return
        if len(ok) < len(paths):
            self.toast(f"Pominięto {len(paths) - len(ok)} plik(ów) nieobsługiwanego typu")
        UploadDialog(self, ok).present()

    def _choose_files(self, *_):
        dlg = Gtk.FileDialog()
        dlg.set_title("Wybierz zdjęcia i wideo do wysłania")
        filt = Gtk.FileFilter()
        filt.set_name("Zdjęcia i wideo")
        for ext in ICloud.UPLOAD_EXT:
            filt.add_suffix(ext[1:])
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(filt)
        dlg.set_filters(filters)

        def done(d, res):
            try:
                files = d.open_multiple_finish(res)
            except GLib.Error:
                return  # anulowano
            paths = [files.get_item(i).get_path() for i in range(files.get_n_items())]
            self._offer_upload([p for p in paths if p])

        dlg.open_multiple(self, None, done)

    def after_upload(self, album_name):
        self.toast("Zdjęcia wysłane do iCloud")
        if self.cur_album is not None and (
                self.cur_title == SMART_PL["All Photos"][0] or album_name == self.cur_title):
            # nowe zdjęcia pojawiają się po chwili przetwarzania po stronie Apple
            GLib.timeout_add_seconds(
                4, lambda: (self.load_album(self.cur_album), False)[1])

    # --- mpv jako zapas ---
    # --- informacje i menu prawego przycisku ---
    def show_info(self, obj):
        if obj is None:
            return
        self.last_obj = obj
        InfoDialog(self, obj).present()

    def _info_clicked(self, *_):
        if self.last_obj is None:
            self.toast("Kliknij zdjęcie prawym przyciskiem i wybierz „Informacje”")
        else:
            self.show_info(self.last_obj)

    def _tile_context(self, tile, x, y):
        if tile.bound is not None:
            self.show_context_menu(tile, x, y, tile.bound)

    def show_context_menu(self, widget, x, y, obj):
        if obj is None:
            return
        self.last_obj = obj
        pop = Gtk.Popover()
        pop.set_parent(widget)
        rect = Gdk.Rectangle()
        rect.x, rect.y, rect.width, rect.height = int(x), int(y), 1, 1
        pop.set_pointing_to(rect)
        pop.set_has_arrow(False)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        def item(label, cb):
            b = Gtk.Button()
            b.add_css_class("flat")
            b.set_child(Gtk.Label(label=label, xalign=0))
            b.connect("clicked", lambda *_: (pop.popdown(), cb()))
            box.append(b)

        item("Informacje", lambda: self.show_info(obj))
        if obj.is_video:
            item("Odtwórz w mpv", lambda: self.play_external(obj))
        if self.cast_target is not None:
            item("Wyślij na TV", lambda: self.cast_asset(obj.asset))
        item("Zapisz oryginał jako…", lambda: self.save_original(obj))
        item("Kopiuj nazwę pliku", lambda: (
            self.get_clipboard().set(obj.asset.filename), self.toast("Skopiowano nazwę pliku")))
        pop.set_child(box)
        pop.connect("closed", lambda p: GLib.idle_add(lambda: (p.unparent(), False)[1]))
        pop.popup()

    def save_original(self, obj):
        dlg = Gtk.FileDialog()
        dlg.set_initial_name(obj.asset.filename)

        def done(d, res):
            try:
                f = d.save_finish(res)
            except GLib.Error:
                return
            path = f.get_path()
            self.toast("Pobieram oryginał…")
            bg(lambda: self.icloud.save_original(obj.asset, path),
               lambda _r, e: self.toast(f"Błąd zapisu: {e}" if e else f"Zapisano: {path}"))

        dlg.save(self, None, done)

    def _video_plan_b(self, obj, ver, why):
        """Streaming przez proxy nie zadziałał - pobierz film do cache i odtwórz lokalnie."""
        self.toast("Streaming filmu nie powiódł się, pobieram go do pamięci podręcznej…")
        log.warning("film %s: plan B po błędzie: %s", obj.asset.filename, why)

        def done(path, err):
            if err:
                log.error("plan B filmu %s: %r", obj.asset.filename, err)
                self.toast(f"Nie udało się odtworzyć filmu: {err}  [log: {DEBUG_LOG}]")
                return
            self.play_external(obj, url=path, _retry=False)

        bg(lambda: self.icloud.fetch_video_file(obj.asset, ver), done)

    def toast(self, text):
        t = Adw.Toast.new(text[:240])
        t.set_timeout(8)
        self.toasts.add_toast(t)

    def external_video_ok(self):
        return (not self.embedded_video) and shutil.which("mpv") is not None

    def play_external(self, obj, ver=None, url=None, _retry=True):
        """Otwiera wideo (albo część wideo Live Photo) w osobnym oknie mpv."""
        if url is None:
            if ver is None:
                if not obj.is_video:
                    return False
                # lekka wersja H.264 ('medium') zamiast wielkiego oryginału HEVC
                ver = self.icloud.video_version(obj.asset, True)
            if ver is None:
                self.toast("Brak wersji wideo do odtworzenia")
                return False
        if not shutil.which("mpv"):
            self.toast("Zainstaluj mpv: sudo apt install mpv")
            return False
        if url is None:
            url = self.icloud.stream_url(obj.asset, ver)
        mpv_log = CACHE_DIR / "mpv.log"
        try:
            fh = open(mpv_log, "wb")
        except OSError:
            fh = subprocess.DEVNULL
        p = subprocess.Popen(
            ["mpv", "--force-window=immediate", "--hwdec=auto-safe", "--network-timeout=20",
             "--cache=yes", "--demuxer-max-bytes=64MiB", f"--title={obj.asset.filename}", url],
            stdout=fh, stderr=subprocess.STDOUT,
        )
        log.info("mpv: %s (%s)", obj.asset.filename, ver)

        def check():
            rc = p.poll()
            if rc not in (None, 0):
                tail = ""
                try:
                    lines = [x for x in mpv_log.read_text(errors="replace").splitlines()
                             if x.strip()]
                    tail = lines[-1] if lines else ""
                except OSError:
                    pass
                log.error("mpv rc=%s: %s", rc, tail)
                if _retry and obj.is_video and str(url).startswith("http"):
                    self._video_plan_b(obj, ver, f"{tail} (kod {rc})")  # streaming zawiódł
                else:
                    self.toast(f"mpv zakończył się błędem ({rc}): {tail}  [log: {DEBUG_LOG}]")
            return False

        GLib.timeout_add_seconds(4, check)
        return True

    def _on_key(self, _c, keyval, _code, state):
        if keyval == Gdk.KEY_F11:
            if self.is_fullscreen():
                self.unfullscreen()
            else:
                self.fullscreen()
            return True
        if (state & Gdk.ModifierType.CONTROL_MASK
                and self.stack.get_visible_child_name() == "main"):
            if keyval in (Gdk.KEY_plus, Gdk.KEY_equal, Gdk.KEY_KP_Add):
                self.set_tile_size(self.tile_size + 20)
                return True
            if keyval in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract, Gdk.KEY_underscore):
                self.set_tile_size(self.tile_size - 20)
                return True
            if keyval in (Gdk.KEY_0, Gdk.KEY_KP_0):
                self.set_tile_size(TILE_DEFAULT)
                return True
        return False


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id="local.icloudphotos.linux")

    def do_activate(self):
        prov = Gtk.CssProvider()
        prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        Gtk.Window.set_default_icon_name("icloud-photos-linux")
        for old in ("index.json", "albums_index.json", "places.json"):  # po usuniętych Wspomnieniach
            try:
                (CACHE_DIR / old).unlink()
            except OSError:
                pass
        threading.Thread(target=prune_cache, daemon=True).start()
        win = self.props.active_window or MainWindow(self)
        win.present()


if __name__ == "__main__":
    sys.exit(App().run(sys.argv))
