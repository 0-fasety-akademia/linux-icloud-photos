VERSION = "0.13.9"
DATE = "2026-11-06"
CREDITS = "Created by: JGu\nSupported by Claude"
