VERSION = "0.14.0"
DATE = "2026-11-07"
CREDITS = "Created by: JGu\nSupported by Claude"
