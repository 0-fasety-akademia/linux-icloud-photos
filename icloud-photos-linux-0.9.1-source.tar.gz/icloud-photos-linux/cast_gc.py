"""Wysyłanie na Chromecasta (oraz TV z wbudowanym Google Cast) przez bibliotekę pychromecast."""
from __future__ import annotations


class ChromecastTarget:
    kind = "Chromecast"

    def __init__(self, cast):
        self._cast = cast
        self.name = cast.name
        try:
            self.host = str(cast.cast_info.host)
        except Exception:  # noqa: BLE001
            self.host = ""
        self.control_url = f"cast://{self.host}"

    def __repr__(self):
        return f"<Chromecast {self.name} @ {self.host}>"

    def play_uri(self, uri: str, title: str, mime: str, video: bool = False) -> None:
        c = self._cast
        c.wait(timeout=10)
        mc = c.media_controller
        mc.play_media(uri, mime, title=title, autoplay=True)
        mc.block_until_active(timeout=10)

    def stop(self) -> None:
        try:
            self._cast.media_controller.stop()
        finally:
            try:
                self._cast.disconnect(timeout=3)
            except Exception:  # noqa: BLE001
                pass


def discover(timeout: float = 5.0) -> list[ChromecastTarget]:
    try:
        import pychromecast
    except ImportError:
        return []
    casts, browser = pychromecast.get_chromecasts(timeout=timeout)
    try:
        return [ChromecastTarget(c) for c in casts]
    finally:
        browser.stop_discovery()
