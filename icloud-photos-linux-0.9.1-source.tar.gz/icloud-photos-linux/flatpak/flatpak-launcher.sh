#!/bin/sh
# Starts iCloud Photos (Linux) inside the Flatpak sandbox.
for d in /app/lib/python3*/site-packages; do
    [ -d "$d" ] && export PYTHONPATH="$d${PYTHONPATH:+:$PYTHONPATH}"
done
export PYTHONDONTWRITEBYTECODE=1
cd /app/lib/icloud-photos-linux || exit 1
exec python3 app.py "$@"
