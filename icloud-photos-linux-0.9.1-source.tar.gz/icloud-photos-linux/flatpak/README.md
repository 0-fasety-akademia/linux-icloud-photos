# Flatpak package (experimental)

The Flatpak bundles GTK 4, libadwaita and GStreamer from the GNOME runtime, so it behaves the same
on any distribution and does not depend on Ubuntu package names.

**Status: written but not built or tested by the author** (the sandbox it was written in could not
reach Flathub). Expect to fix small things on the first build.

## Build and install

    bash flatpak/build-flatpak.sh
    flatpak run local.icloudphotos.linux

## Remove it (and avoid duplicates with the .deb)

The Flatpak and the `.deb` use the same name and the same desktop id, so with both installed the app
appears twice in the menu. They do not share settings: the Flatpak keeps its data in
`~/.var/app/local.icloudphotos.linux/`, the `.deb` in `~/.config/icloud-photos-linux` and
`~/.cache/icloud-photos-linux`, so you would have to sign in twice.

Remove only the Flatpak (keeps the .deb):

    bash flatpak/remove-flatpak.sh

or by hand:

    flatpak uninstall --delete-data local.icloudphotos.linux
    flatpak uninstall --unused
    rm -rf flatpak/build-dir flatpak/.flatpak-builder local.icloudphotos.linux.flatpak

Check what is installed:

    flatpak list --app | grep -i icloud     # Flatpak
    dpkg -l | grep icloud-photos            # .deb

Remove only the .deb (keeps the Flatpak): `sudo apt remove icloud-photos-linux`
(use `purge` to also delete `/opt/icloud-photos-linux`).

## Notes

- `mpv` is not available inside the sandbox, so videos play in the built-in GTK player (GStreamer + the
  `ffmpeg-full` codec extension). HEIC originals may not decode (no HEIF loader in the runtime); the
  JPEG preview is used instead.
- Permissions: network (iCloud, TV discovery), Wayland/X11, GPU, audio, and the secret service (keyring).
- To publish on Flathub the app id must be changed to a domain you own (for example
  `io.github.<user>.ICloudPhotos`), screenshots must be added to the metainfo file, and Flathub requires
  all Python dependencies to be listed with checksums (generated into `python3-deps.json`).
