VERSION = "0.16.1"
DATE = "2026-11-09"
CREDITS = "Created by: JGu\nSupported by Claude"
